package GuviMavenproject.GuviMavenproject;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class ExcelReader {

	public static void main(String[] args) {
		String fileName = "C:\\Users\\musht\\Pictures\\Screenshots\\Shaffna\\Excel3.xlsx";
          try (FileInputStream fileIn = new FileInputStream(fileName)) {
          Workbook workbook = WorkbookFactory.create(fileIn);
            org.apache.poi.ss.usermodel.Sheet sheet = workbook.getSheet("Sheet1");
              for (Row row : sheet) {
                for (org.apache.poi.ss.usermodel.Cell cell : row) {
                    switch (cell.getCellType()) {
                        case STRING:
                            System.out.print(cell.getStringCellValue() + "\t");
                            break;
                        case NUMERIC:
                            System.out.print((int) cell.getNumericCellValue() + "\t");
                            break;
                        default:
                            System.out.print("Unknown\t");
                    }
                }
                System.out.println();
            }

            workbook.close();
        } catch (IOException e) {
            System.out.println("Error reading the file: " + e.getMessage());
        }
        File excelFile = new File(fileName);

        if (!excelFile.exists()) {
            System.out.println("File does not exist: " + fileName);
            return;
        }
            if (Desktop.isDesktopSupported()) {         // Open the file using Desktop API
            try {
                Desktop.getDesktop().open(excelFile);
                System.out.println("Excel file opened successfully!");
            } catch (IOException e) {
                System.out.println("Error opening the file: " + e.getMessage());
            }
        } else {
            System.out.println("Desktop is not supported on this system.");
        }

	}

}
