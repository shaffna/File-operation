package GuviMavenproject.GuviMavenproject;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWriter {

	public static void main(String[] args) {
		String fileName = "C:\\Users\\musht\\Pictures\\Screenshots\\Shaffna\\Excel3.xlsx";

		XSSFWorkbook workbook = new XSSFWorkbook();

		XSSFSheet sheet = workbook.createSheet("Sheet1");

		String[][] data = { { "Name", "Age", "Email" }, { "Joe", "23", "joe@test.com" },
				{ "john", "28", "john@test.com" }, { "Mike", "29", "mike@example.com" },
				{ "Kim", "15", "kim@example.com" } };

		for (int i = 0; i < data.length; i++) {
			XSSFRow row = sheet.createRow(i);
			for (int j = 0; j < data[i].length; j++) {
				XSSFCell cell = row.createCell(j);
				cell.setCellValue(data[i][j]);
			}
		}

		try (FileOutputStream fileOut = new FileOutputStream(fileName)) {
			workbook.write(fileOut);
			System.out.println("Excel file written successfully!");
		} catch (IOException e) {
			System.out.println("Error writing to file: " + e.getMessage());
		} finally {
			try {
				workbook.close();
			} catch (IOException e) {
				e.printStackTrace();

			}
		}
		File excelFile = new File(fileName);
		if (Desktop.isDesktopSupported()) { // Open the file using Desktop API
			try {
				Desktop.getDesktop().open(excelFile);
				System.out.println("Excel file opened successfully!");
			} catch (IOException e) {
				System.out.println("Error opening the file: " + e.getMessage());
			}
		} else {
			System.out.println("Desktop is not supported on this system.");
		}
	}
}
